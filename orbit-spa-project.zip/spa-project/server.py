"""Tiny dev server for the SPA: serves index.html for any unknown path so deep links
(e.g. /products/3) work on refresh. Run:  python server.py  then open http://localhost:8000"""
import http.server, os, socketserver

class SPAHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        path = self.translate_path(self.path.split("?")[0])
        if not os.path.exists(path) or os.path.isdir(path) and self.path != "/":
            self.path = "/index.html"
        return super().do_GET()

with socketserver.TCPServer(("", 8000), SPAHandler) as httpd:
    print("Serving on http://localhost:8000")
    httpd.serve_forever()
