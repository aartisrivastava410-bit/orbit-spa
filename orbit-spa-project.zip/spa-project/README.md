# Orbit SPA – Week 5 Frontend Project

A Single Page Application simulation built with plain HTML, CSS and JavaScript (no frameworks).

## Run
- Easiest: open `index.html` (uses hash routing, e.g. `#/products`).
- Full History API mode: `python server.py` and open http://localhost:8000 (clean URLs like `/products/3`, deep links work on refresh).

## Structure
```
index.html        main container (#app)
css/style.css     styles, transitions, responsive layout
js/data.js        simulated async data source
js/views.js       view templates (home, gadgets, detail, about, contact, 404)
js/router.js      client-side router (History API + hash fallback)
server.py         optional SPA dev server
```

## Features
Dynamic content loading, route params, animated transitions, loading bar, 404 + error handling,
active-link highlighting, live filter, form validation, accessible focus management, responsive menu.
