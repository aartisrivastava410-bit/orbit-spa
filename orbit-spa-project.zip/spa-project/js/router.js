/* Client-side router.
   - Uses the History API (pushState / popstate) when served over http(s).
   - Falls back to hash routing (#/path) when opened directly from disk (file://),
     because pushState to new paths does not work there. */
(() => {
  const app = document.getElementById("app");
  const progress = document.getElementById("progress");
  const nav = document.getElementById("nav");
  const toggle = document.getElementById("menu-toggle");
  const useHistory = location.protocol.startsWith("http");
  const APP_NAME = "Orbit SPA";

  // Route table: pattern -> view. ":id" style segments become params.
  const routes = [
    { path: "/", view: "home", name: "home" },
    { path: "/products", view: "products", name: "products" },
    { path: "/products/:id", view: "product", name: "products" },
    { path: "/about", view: "about", name: "about" },
    { path: "/contact", view: "contact", name: "contact" }
  ];

  const state = { current: null, navId: 0 };

  function currentPath() {
    if (useHistory) return location.pathname.replace(/\/index\.html$/, "") || "/";
    return location.hash.replace(/^#/, "") || "/";
  }

  function match(path) {
    const clean = path.replace(/\/+$/, "") || "/";
    for (const r of routes) {
      const keys = [];
      const re = new RegExp("^" + r.path.replace(/:(\w+)/g, (_, k) => (keys.push(k), "([^/]+)")) + "$");
      const m = clean.match(re);
      if (m) return { route: r, params: Object.fromEntries(keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) };
    }
    return null;
  }

  function setProgress(on) {
    progress.classList.toggle("active", on);
  }

  function setActiveLink(name) {
    nav.querySelectorAll("a").forEach((a) => {
      const active = a.dataset.route === name;
      a.classList.toggle("active", active);
      active ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current");
    });
  }

  async function render() {
    const id = ++state.navId; // guards against out-of-order async renders
    const found = match(currentPath());
    const view = found ? Views[found.route.view] : Views.notFound;
    const params = found ? found.params : {};

    app.classList.add("leaving");
    setProgress(true);
    await new Promise((r) => setTimeout(r, 150)); // let fade-out play

    let html;
    try {
      html = await view.render(params);
    } catch (err) {
      html = `<section class="hero"><h1>Something went wrong</h1><p>${esc(err.message)}</p>
              <a href="/products" data-link class="btn">Back to gadgets</a></section>`;
      view.title = "Error";
    }
    if (id !== state.navId) return; // a newer navigation took over

    app.innerHTML = html;
    app.classList.remove("leaving");
    app.classList.add("entering");
    requestAnimationFrame(() => requestAnimationFrame(() => app.classList.remove("entering")));
    setProgress(false);

    document.title = `${view.title} · ${APP_NAME}`;
    setActiveLink(found ? found.route.name : "");
    if (view.after) view.after(params);
    state.current = currentPath();
    window.scrollTo({ top: 0 });
    app.focus({ preventScroll: true });
  }

  function navigate(path) {
    if (path === currentPath()) return;
    if (useHistory) {
      history.pushState({ path }, "", path);
      render();
    } else {
      location.hash = path; // triggers hashchange -> render
    }
  }

  // Intercept clicks on [data-link] anchors
  document.addEventListener("click", (e) => {
    const link = e.target.closest("a[data-link]");
    if (!link || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    navigate(link.getAttribute("href"));
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  });

  // Back / forward buttons
  window.addEventListener(useHistory ? "popstate" : "hashchange", render);

  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
  });

  render();
})();
