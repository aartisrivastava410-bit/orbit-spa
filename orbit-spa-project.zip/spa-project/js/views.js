/* View functions: each returns an HTML string (or a Promise of one).
   Optional `after` hooks attach event listeners once the DOM is in place. */
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const Views = {
  home: {
    title: "Home",
    render: () => `
      <section class="hero">
        <h1>Welcome to <span class="accent">Orbit</span></h1>
        <p>A tiny Single Page Application. Navigate anywhere &mdash; the page never reloads.</p>
        <a href="/products" data-link class="btn">Browse gadgets</a>
      </section>
      <section class="grid three">
        <article class="card"><h3>⚡ No reloads</h3><p>Content is swapped in the DOM using JavaScript.</p></article>
        <article class="card"><h3>🔗 Real URLs</h3><p>The History API keeps the address bar and Back button in sync.</p></article>
        <article class="card"><h3>🛟 Error handling</h3><p>Unknown routes and failed loads show friendly messages.</p></article>
      </section>`
  },

  products: {
    title: "Gadgets",
    async render() {
      const items = await fetchProducts();
      return `
        <h1>Gadgets</h1>
        <label class="search"><span class="sr">Filter gadgets</span>
          <input id="filter" type="search" placeholder="Filter by name or category…">
        </label>
        <section id="product-grid" class="grid three">${productCards(items)}</section>`;
    },
    after() {
      const input = document.getElementById("filter");
      const grid = document.getElementById("product-grid");
      input.addEventListener("input", () => {
        const q = input.value.trim().toLowerCase();
        const list = PRODUCTS.filter((p) => (p.name + p.category).toLowerCase().includes(q));
        grid.innerHTML = list.length ? productCards(list) : `<p class="muted">No gadgets match “${esc(q)}”.</p>`;
      });
    }
  },

  product: {
    title: "Gadget details",
    async render({ id }) {
      const p = await fetchProduct(id);
      Views.product.title = p.name;
      return `
        <a href="/products" data-link class="back">&larr; Back to gadgets</a>
        <article class="detail">
          <div class="detail-emoji" aria-hidden="true">${p.emoji}</div>
          <div>
            <span class="tag">${esc(p.category)}</span>
            <h1>${esc(p.name)}</h1>
            <p>${esc(p.desc)}</p>
            <p class="price">$${p.price}</p>
          </div>
        </article>`;
    }
  },

  about: {
    title: "About",
    render: () => `
      <h1>About this project</h1>
      <p>Orbit simulates a small SPA to demonstrate client-side routing, dynamic content loading and state management using plain HTML, CSS and JavaScript &mdash; with no frameworks.</p>
      <ul class="checks">
        <li>Client-side router built on the History API</li>
        <li>Dynamic route parameters (<code>/products/3</code>)</li>
        <li>Animated page transitions and loading indicator</li>
        <li>404 page and error handling for failed loads</li>
        <li>Accessible: focus management, ARIA live region, skip link</li>
      </ul>`
  },

  contact: {
    title: "Contact",
    render: () => `
      <h1>Contact</h1>
      <form id="contact-form" class="form" novalidate>
        <label>Name <input name="name" required minlength="2"></label>
        <label>Email <input name="email" type="email" required></label>
        <label>Message <textarea name="message" rows="4" required minlength="10"></textarea></label>
        <p id="form-msg" class="form-msg" role="status"></p>
        <button class="btn" type="submit">Send message</button>
      </form>`,
    after() {
      const form = document.getElementById("contact-form");
      const msg = document.getElementById("form-msg");
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (!form.checkValidity()) {
          msg.textContent = "Please fill in all fields correctly.";
          msg.className = "form-msg error";
          form.reportValidity();
          return;
        }
        msg.textContent = "Thanks! Your message was sent (simulated).";
        msg.className = "form-msg ok";
        form.reset();
      });
    }
  },

  notFound: {
    title: "Page not found",
    render: () => `
      <section class="hero">
        <h1>404</h1>
        <p>Sorry, that page doesn't exist.</p>
        <a href="/" data-link class="btn">Go home</a>
      </section>`
  }
};

function productCards(items) {
  return items.map((p) => `
    <a class="card product" href="/products/${p.id}" data-link>
      <div class="emoji" aria-hidden="true">${p.emoji}</div>
      <h3>${esc(p.name)}</h3>
      <span class="tag">${esc(p.category)}</span>
      <p class="price">$${p.price}</p>
    </a>`).join("");
}
