/* Simulated "backend" data. Loaded asynchronously via fetchProducts()/fetchProduct()
   so the app can demonstrate loading states and error handling. */
const PRODUCTS = [
  { id: 1, name: "Nova Earbuds", price: 59, category: "Audio", emoji: "🎧",
    desc: "Wireless earbuds with 30-hour battery life and active noise reduction." },
  { id: 2, name: "Pulse Watch", price: 129, category: "Wearables", emoji: "⌚",
    desc: "A fitness watch tracking steps, heart rate and sleep with a bright AMOLED display." },
  { id: 3, name: "Lumen Lamp", price: 35, category: "Home", emoji: "💡",
    desc: "A smart desk lamp with adjustable colour temperature and touch controls." },
  { id: 4, name: "Atlas Backpack", price: 79, category: "Travel", emoji: "🎒",
    desc: "Water-resistant 25L backpack with a padded laptop sleeve and hidden pockets." },
  { id: 5, name: "Zen Speaker", price: 49, category: "Audio", emoji: "🔊",
    desc: "Portable Bluetooth speaker with deep bass and a 12-hour battery." },
  { id: 6, name: "Spark Charger", price: 25, category: "Accessories", emoji: "🔌",
    desc: "65W fast charger that powers a laptop and a phone at the same time." }
];

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

async function fetchProducts() {
  await delay(450);
  return PRODUCTS;
}

async function fetchProduct(id) {
  await delay(350);
  const item = PRODUCTS.find((p) => p.id === Number(id));
  if (!item) throw new Error("Product not found");
  return item;
}
